# ICG-AutoExploiterBoT
<br> :heavy_exclamation_mark: Edit Line 44 Add your Email Address for Add admin joomla Exploit ( Use outlook.com Mail! )  :heavy_check_mark:<br>
<h3> :warning:Note! : We don't Accept any responsibility for any illegal usage.</h3><br>
<br>

<h3>- only work on 2.7 version python</h3>
<br><h3> free Penetration Testing tool </h3>

<br>
<center><a href="http://www.youtube.com/watch?feature=player_embedded&v=XyiQZmsGLAw
" target="_blank"><img src="http://img.youtube.com/vi/XyiQZmsGLAw/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="640" height="380" border="30" /></a></center>

[![Watch the video](https://raw.githubusercontent.com/04x/ICG-AutoExploiterBoT/master/screen/screen2.PNG)](https://www.aparat.com/v/ntyJd)
<br>
[![Watch the video](https://raw.githubusercontent.com/04x/ICG-AutoExploiterBoT/master/screen/log.PNG)](https://www.aparat.com/v/ntyJd)


<br>
<h3>OsCommerce Exploits :boom:</h3>
<br>
- OsCommerce 2.x Core RCE<br>
<h3>Drupal Exploits :boom:</h3><br>
- Drupal Add admin <br>
- Drupal BruteForcer<br>
- Drupal Geddon2 Exploit - Upload shell + Index <br>
<h3>Joomla Exploits :boom:</h3><br>
- Joomla BruteForcer<br>
- RCE joomla 1.x < 3.x<br>
- Add Admin joomla 0day 3.x<br>
- JCE Index + upload Shell Priv8<br>
- jdownloads index + shell priv8<br>
- com_media Index<br>
- Com_fabrik index + Shell priv8<br>
- com_alberghi Index <br>
- Com_AdsManager index + Shell priv8 Method<br>
- Com_MyBlog Index <br>
- Com_CCkJseblod Config Download<br>
- Com_Macgallery Config Download<br>
- Com_Joomanager Config download<br>
- Com_Hdflvplayer Config Download<br>
- Com_s5_media_player Config Download<br>
- Com_FoxContact UploadShell + Index<br>
- Com_Jbcatalog Upload Index & Shell<br>
- Com_SexyContactform Upload Index & Shell<br>
- Com_rokdownloads Upload Index & Shell<br>
- Com_extplorer Upload Index & Shell<br>
- Com_jwallpapers Upload Index & Shell<br>
- Com_facileforms Upload Index & Shell<br>

<h3>Wordpress Exploits :boom:</h3><br>
- Wp 4.7 Content Injection <br>
- Revslider css Index + Config + Shell Upload<br>
- wp-user-frontend Exploit<br>
- gravity-forms Exploit<br>
- HD-webplayer Exploit<br>
- wysija Exploit<br>
- pagelines Exploit<br>
- Headwaytheme Exploit<br>
- addblockblocker Exploit<br>
- cherry-plugin Exploit<br>
- formcraft Exploit<br>
- userpro take ADmin panel wordpress [priv8]  Exploit<br>
- wp-mobile-detector Exploit<br>
- wp-job-manager Exploit<br>
- woocomerce Exploit<br>
- viral-optins Exploit<br>
- Wordpress Downloads-Manager Exploit Upload shell + Index<br> 
- Wordpress Category-Page-icons Exploit <br>
- wp_support_plus_responsive_ticket_system Download Config<br>
- wp_miniaudioplayer Download Config<br>
- eshop_magic Download Config<br>
- ungallery Download Config<br>
- barclaycart Upload Index & Shell<br>
<h3>Prestashop Exploits :boom:</h3><br>
- lib Prestashop Module Exploit<br>
- psmodthemeoptionpanel Prestashop Module Exploit<br>
- tdpsthemeoptionpanel Prestashop Module Exploit<br>
- megamenu Prestashop Module Exploit<br>
- nvn_export_orders Prestashop Module Exploit<br>
- pk_flexmenu Prestashop Module Exploit<br>
- wdoptionpanel Prestashop Module Exploit<br>
- fieldvmegamenu Prestashop Module Exploit<br>
- wg24themeadministration Prestashop Module Exploit<br>
- videostab Prestashop Module Exploit<br>
- cartabandonmentproOld Prestashop Module Exploit<br>
- cartabandonmentpro Prestashop Module Exploit<br>
- advancedslider Prestashop Module Exploit<br>
- attributewizardpro_x Prestashop Module Exploit<br>
- attributewizardpro3 Prestashop Module Exploit<br>
- attributewizardpro2 Prestashop Module Exploit<br>
- attributewizardpro Prestashop Module Exploit<br>
- jro_homepageadvertise Prestashop Module Exploit<br>
- homepageadvertise2 Prestashop Module Exploit<br>
- homepageadvertise Prestashop Module Exploit<br>
- productpageadverts Prestashop Module Exploit<br>
- simpleslideshow Prestashop Module Exploit<br>
- vtermslideshow Prestashop Module Exploit<br>
- soopabanners Prestashop Module Exploit<br>
- soopamobile Prestashop Module Exploit<br>
- columnadverts Prestashop Module Exploit<br>

<h3>Opencart Exploits :boom:</h3><br>
- Opencart BruteForce<br>

